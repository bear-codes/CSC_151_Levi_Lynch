package labs.example.mammal;

public class Dog extends Mammal {

    public Dog() {
        super();
    }
    
    public void bark() {
        System.out.println("The mammal is barking!");
    }
}
