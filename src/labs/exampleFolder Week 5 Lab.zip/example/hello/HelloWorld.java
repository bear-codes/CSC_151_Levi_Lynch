/*
Author: Levi Lynch
Date: 1/21/26
@purpose: My First Java Program 

note: This program should reside in the directory pat has follows-> CSC_151_LeviLynch
<<<<<<< HEAD
java -cp bin labs.example.hello.HelloWorld
javac -d bin src/labs/example/hello/*.java

*/


package labs.example.hello;


public class HelloWorld
{
    public static void main (String[] args)
    {
        System.out.println("Hello World");
    }
}